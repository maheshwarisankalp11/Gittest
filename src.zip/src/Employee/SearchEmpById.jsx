import React, { Component } from 'react'
import axios from 'axios'
import Table from 'react-bootstrap/Table';
import { Link } from 'react-router-dom';


export default class SearchEmpById extends Component {
    constructor() {
        super();
        this.state = {
            employee_Id: '',
            full_Name: '',
            email_Address: '',
            mobile_Number: '',
            date_Joined: '',
            department: '',
            
        }
        this.SearchEmpById = this.SearchEmpById.bind(this);
    }
    SearchEmpById(e) {

        let employee_Id = localStorage.getItem("employee_Id");
        axios.get('http://localhost:59992/api/EmployeeInfo/FindbyID/' + employee_Id)
            .then(response => {
                this.setState({
                    employee_Id: response.data.employee_Id,
                    full_Name: response.data.full_Name,
                    email_Address: response.data.email_Address,
                    mobile_Number: response.data.mobile_Number,
                    date_Joined: response.data.date_Joined,
                    department: response.data.department,
                    
                })
            }).catch(error => {
                console.warn(error);
            })
    }
    componentDidMount() {
        this.SearchEmpById()
    }
    render() {
        let employee_Id = localStorage.getItem("employee_Id");
        const { full_Name } = this.state;
        const { email_Address } = this.state;
        const { mobile_Number } = this.state;
        const { date_Joined } = this.state;
        const { department } = this.state;
        
        return (
            <>
               
                <br></br>
                <label><h1>My Details</h1></label>
                
                <Table striped bordered hover variant="dark">
      <thead>
        <tr>
          <th>Employee Id</th>
          <th>Full Name</th>
          <th>Email Address</th>
          <th>Mobile Number</th>
          <th>Date Joined</th>
          <th>Department</th>
          
        </tr>
      </thead>
      <tbody>
        <tr>
          
          <td>{this.state.employee_Id}</td>
          <td>{full_Name}</td>
          <td>{email_Address}</td>
          <td>{mobile_Number}</td>
          <td>{date_Joined}</td>
          <td>{department}</td>
          
        </tr>
      </tbody>
    </Table>
    <p> <Link as={Link} to="/EmployeeDashboard2">
        <button type="button" class="btn btn-sm btn-outline-secondary">Back</button>
        </Link></p>

            </>

        )
    }
}