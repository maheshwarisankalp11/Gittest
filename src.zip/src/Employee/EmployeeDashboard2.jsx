import React, { Component } from 'react'
import Card from 'react-bootstrap/Card';
import { Link } from 'react-router-dom';
import Login from '../Account/Login';
import './EmployeeDashboard2.css'
import HexaBlk from '../Images/HexaBlk.png'

export default class EmployeeDashboard2 extends Component {
    constructor() {
        super();
    }
    
    render() {
        let UserName = localStorage.getItem("UserName");
        return (
            <> 


           

                <header>
                    {/* <div class="collapse bg-dark" id="navbarHeader">
                        <div class="container">
                            <div class="row">
                                <div class="col-sm-8 col-md-7 py-4">
                                    <h4 class="text-white">About</h4>
                                    <p class="text-muted">Add some information about the album below, the author, or any other background context. Make it a few sentences long so folks can pick up some informative tidbits. Then, link them off to some social networking sites or contact information.</p>
                                </div>
                                <div class="col-sm-4 offset-md-1 py-4">
                                    <h4 class="text-white">Contact</h4>
                                    <ul class="list-unstyled">
                                        <li><a href="#" class="text-white">Follow on Twitter</a></li>
                                        <li><a href="#" class="text-white">Like on Facebook</a></li>
                                        <li><a href="#" class="text-white">Email me</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div> */}
                    <div class="navbar navbar-dark bg-dark shadow-sm">
                    <div className="logo-image ">
                                <img src={HexaBlk}width="80" height="60" ></img>
                                </div>
                        <div class="container">
                            <a href="#" class="navbar-brand d-flex align-items-center">
                            
                            
                                <strong>Welcome, {UserName}</strong>
                                
                            </a>
                            <p> <Card.Link as={Link} to="/Login">
                            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarHeader" aria-controls="navbarHeader" aria-expanded="false" aria-label="Toggle navigation"> Logout
                                {/* <span class="navbar-toggler-icon"></span> */}
                            </button>
                            </Card.Link>
                            </p>
                            
                        </div>
                    </div>
                </header>

                

                    <section class="py-5 text-center container">
                        <div class="row py-lg-5">
                            <div class="col-lg-6 col-md-8 mx-auto">
                                <h1 class="fw-light">Leave Management System</h1>
                                <h2 class="fw-light">Employee Dashboard</h2>
                                
                                {/* <p>
                                    <a href="#" class="btn btn-primary my-2">Main call to action</a>
                                    <a href="#" class="btn btn-secondary my-2">Secondary action</a>
                                </p> */}
                            </div>
                        </div>
                    </section>

                    <div class="album py-5 bg-light">
                        <div class="container">

                            <div class="row row-cols-1 row-cols-sm-2 row-cols-md-2 g-3">
                                <div class="col">
                                    <div class="card shadow-sm">
                                        

                                        <div class="card-body">
                                        <h3 id="heading">Employee Section</h3>
                                            <p class="card-text"> Here Employee can see his/her details.</p>
                                            <div class="d-flex justify-content-between align-items-center">
                                                <div class="btn-group">
                                                   <p> <Card.Link as={Link} to="/EmpDetails">
                                                    <button type="button" class="btn btn-sm btn-outline-secondary">View Details</button>
                                                    </Card.Link></p>
                                                    

                            
                                                </div>
                                                
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col">
                                    <div class="card shadow-sm">
                                        {/* <svg class="bd-placeholder-img card-img-top" width="100%" height="225" xmlns="hexawareLogo.png" role="img" aria-label="Placeholder: Thumbnail" preserveAspectRatio="xMidYMid slice" focusable="false"><title>Placeholder</title><rect width="100%" height="100%" fill="#55595c" /><text x="50%" y="50%" fill="#eceeef" dy=".3em">Thumbnail</text></svg> */}

                                        <div class="card-body">
                                        <h3 id="heading"> My Manager</h3>
                                            <p class="card-text">Here Employee can see his/her manager details</p>
                                            <div class="d-flex justify-content-between align-items-center">
                                                <div class="btn-group">
                                                    
                                                    <p><Card.Link as={Link} to="/ManagerDetails">
                                                    <button type="button" class="btn btn-sm btn-outline-secondary">View Details</button>    
                                                    </Card.Link></p>
                                                </div>
                                                
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col">
                                    <div class="card shadow-sm">
                                        

                                        <div class="card-body">
                                        <h3 id="heading">Leave Section</h3>
                                        <p class="card-text">Want to apply for leave, click below</p>
                                            
                                            <div class="d-flex justify-content-between align-items-center">
                                                <div class="btn-group">
                                                <p> <Card.Link as={Link} to="/LeaveDetails">
                                                <button type="button" class="btn btn-sm btn-outline-secondary">Apply Now</button>
                                                    </Card.Link></p>
                                                
                                                <p> <Card.Link as={Link} to="/ApplicationSts">
                                                <button type="button" class="btn btn-sm btn-outline-secondary">View Applications</button>
                                                    </Card.Link></p>
                                                    
                                                </div>
                                                {/* <small class="text-muted">9 mins</small> */}
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="col">
                                    <div class="card shadow-sm">
                                        

                                        <div class="card-body">
                                        <h3 id="heading">Employees Pending Leave Applications</h3>
                                            <p class="card-text">Please Login and view your Employee's pending applications</p>
                                            <div class="d-flex justify-content-between align-items-center">
                                                <div class="btn-group">
                                                    <p><Card.Link as={Link} to="/ManagerLogin">
                                                        <button type="button" class="btn btn-sm btn-outline-secondary">Manager Login</button>
                                                    </Card.Link></p>
                                                </div>
                                                
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                    </div>

                

                <footer class="text-muted py-5">
                    <div class="container">
                        <p class="float-end mb-1">
                            <a href="#">Back to top</a>
                        </p>
                        <p class="lead text-muted">This LMS project is created by Team-07.</p>
                        {/* <p class="mb-1">Album example is &copy; Bootstrap, but please download and customize it for yourself!</p>
                        <p class="mb-0">New to Bootstrap? <a href="/">Visit the homepage</a> or read our <a href="../getting-started/introduction/">getting started guide</a>.</p> */}
                    </div>
                </footer>


                

                </>
            


        )
    }
}
