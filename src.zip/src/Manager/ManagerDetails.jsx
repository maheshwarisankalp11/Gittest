import React, { Component } from 'react'
import axios from 'axios'
import Table from 'react-bootstrap/Table';
import { Link } from 'react-router-dom';


export default class ManagerDetails extends Component {
  constructor() {
    super();
    this.state = {
      manager_Id: '',
      full_Name: '',
      email_Address: '',
      mobile_Number: ''

    }
    this.SearchEmpById = this.SearchEmpById.bind(this);
  }
  SearchEmpById(e) {

    let manager_Id = localStorage.getItem("manager_Id");
    axios.get('http://localhost:59992/api/ManagerInfo/ShowByID?Employee_Id=' + manager_Id)
      .then(response => {
        this.setState({
          manager_Id: response.data.manager_Id,
          full_Name: response.data.full_Name,
          email_Address: response.data.email_Address,
          mobile_Number: response.data.mobile_Number

        })
      }).catch(error => {
        console.warn(error);
      })
  }
  componentDidMount() {
    this.SearchEmpById()
  }
  render() {

    const { manager_Id } = this.state;
    const { full_Name } = this.state;
    const { email_Address } = this.state;
    const { mobile_Number } = this.state;

    return (
      <>
        {/* <div>SearchEmpById</div>
            <lable>Enter Employee ID</lable>
             <input type="text" name="employee_Id" defaultValue={employee_Id} onChange={(e)=>this.setState({employee_Id:e.target.value})}></input> 
            <button onClick={(e)=>this.SearchEmpById(e)}>SearchID</button>  */}
        <br></br>
        <label><h1>My Manager Details</h1></label>
        <Table striped bordered hover variant="dark">
      <thead>
        <tr>
          <th>manager Id</th>
          <th>Full Name</th>
          <th>Email Address</th>
          <th>Mobile number</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>{manager_Id}</th>
          <th>{full_Name}</th>
          <th>{email_Address}</th>
          <th>{mobile_Number}</th>

        </tr> 
      </tbody>
    </Table>
    <p> <Link as={Link} to="/EmployeeDashboard2">
        <button type="button" class="btn btn-sm btn-outline-secondary">Back</button>
        </Link></p>

      </>

    )
  }
}
