import React, { Component } from 'react'
import Card from 'react-bootstrap/Card';
import { Link } from 'react-router-dom';
import axios from 'axios'
import ApproveDeny from '../LeaveSection/ApproveDeny'

export default class ManagerLogin extends Component {


  constructor() {
    super();
    this.state = {
      Manager: [],
      email_Address: '',
      password: ''
    }
    this.ManagerLogin = this.ManagerLogin.bind(this);
    this.handleChange = this.handleChange.bind(this);
  }

  ManagerLogin(e) {
    e.preventDefault();
    let email_Address = this.state.email_Address;
    let password = this.state.password;
    axios.get('http://localhost:59992/api/ManagerInfo/Login/' + email_Address + '/' + password)
      .then(res => res
      )
      .then(result => {
        console.log(result);
        localStorage.setItem("employee_Id", result.data.employee_Id);
        localStorage.setItem("manager_Id", result.data.manager_Id);
        //alert(result);
        if (result != null) {
          //alert("Valid");

          window.location = "/ApproveDeny";
          localStorage.setItem("UserName", email_Address)

        }
        else {
          alert("InValid");


        }
      })
      .catch(err => {
        console.log(err);
        alert("Enter valid credentials");



      });
  }
  handleChange(e) {
    this.setState(e);
  }



    render() {
        return (
          <>
          <br/>
          <br/>
          <br/>
          <br/>
          <br/>
            <div class="row row-cols-1 row-cols-sm-1 row-cols-md-2 g-4">

          <Card >

            <Card.Body>

              <form>

                <h2>Manager Login</h2>

                <div className="form-group">
                  <label>Email</label>
                  <input type="email" name='email' onChange={(e) => this.handleChange({ email_Address: e.target.value })} className="form-control" placeholder="Enter email" />
                  <label className="text-muted">
                    We'll never share your email and password with anyone else.
        </label>
                </div>

                <div className="form-group">
                  <label>Password</label>
                  <input type="password" name='password' onChange={(e) => this.handleChange({ password: e.target.value })} className="form-control" placeholder="Enter password" />
                  
                </div>

                
                <br/>
                <button type="submit" onClick={this.ManagerLogin} className="btn btn-outline-info">Login</button>
                <br/><br/>
                <p> <Link as={Link} to="/EmployeeDashboard2">
                     <button type="button" class="btn btn-outline-info">Back</button>
                </Link></p>
                

                


              </form>
            </Card.Body>
          </Card>
        </div>
        </>

        )
    }
}
