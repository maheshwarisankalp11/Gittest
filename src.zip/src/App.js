
import './App.css';


import 'bootstrap/dist/css/bootstrap.css';
import 'bootstrap/dist/js/bootstrap.bundle';
import BasicNavbar from './BasicNavbar';
// import Login from './Account/Login';
// import EmployeeDashboard from './Employee/EmployeeDashboard';
// import LeaveDetails from './LeaveSection/LeaveDetails';




function App() {
  
  return (
    
 <BasicNavbar></BasicNavbar>
  )
}

export default App;
