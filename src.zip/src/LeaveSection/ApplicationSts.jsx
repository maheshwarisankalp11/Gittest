import React, { Component } from 'react'
import Table from 'react-bootstrap/Table';
import axios from 'axios';
import { Link } from 'react-router-dom';



export default class ApplicationSts extends Component {
    constructor(){
        super();
        this.state={
            AppliedLeave:[]
        }
        
    }
    componentDidMount(){
        const UserID = localStorage.getItem("employee_Id");
        axios.get('http://localhost:59992/api/LeaveInfo/ShowAll_Leaves/' + UserID).then(Response=>{
            this.setState({AppliedLeave:Response.data})
        }).catch(error=>{
           console.warn(error); 
        })
    }

   
    
    render() {
        const {AppliedLeave}=this.state;
        return (
            <>
           <label> <h1>My Applications</h1></label>
            <Table striped bordered hover variant="dark">
        <thead>
          <tr>
            
            <th>leave ID</th>
            <th>employee ID</th>
            <th>number of Days</th>
            <th>From Date</th>
            <th>To Date</th>
            <th>Leave Type</th>
            <th>Status</th>
            <th>Reason</th>
            <th>Applied on</th>
            <th>Manager comments</th>
          </tr>
        </thead>
        <tbody>
            {
                AppliedLeave.map(a=>
                    
            <tr>
            
            <td>{a.leave_ID}</td>
            <td>{a.employee_Id}</td>
            <td>{a.number_of_Days}</td>
            <td>{a.start_Date}</td>
            <td>{a.end_Date}</td>
            <td>{a.leave_Type}</td>
            <td>{a.status}</td>
            <td>{a.reason}</td>
            <td>{a.applied_ON}</td>
            <td>{a.manager_comments}</td>
            
          </tr>
                    
                    )
            }
          
          
        </tbody>
      </Table>
      <p> <Link as={Link} to="/EmployeeDashboard2">
        <button type="button" class="btn btn-sm btn-outline-secondary">Back</button>
        </Link></p>
      </>
        )
    }
}

