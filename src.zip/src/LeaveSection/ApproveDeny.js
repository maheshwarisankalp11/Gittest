import React, { Component } from 'react'
import Table from 'react-bootstrap/Table';
import { Link } from 'react-router-dom';
import axios from 'axios'


export default class ApproveDeny extends Component {
  constructor(){
    super();
    this.state = {
      LeaveArr:[]
    }
  }
  componentDidMount(){
    const manager_Id = localStorage.getItem("manager_Id");
    axios.get('http://localhost:59992/api/LeaveInfo/ShowAllPendingLeave?id=' + manager_Id).then(Response=>{
        this.setState({LeaveArr:Response.data})
    }).catch(error=>{
       console.warn(error); 
    })
}
  render() {
    const {LeaveArr}=this.state;
    
    
    return (
      <>
        <label><h1>Pending Applications</h1></label>
      <Table striped bordered hover variant="dark">
        <thead>
          <tr>
            <th>Leave ID</th>
            <th>Employee ID</th>
            <th>Number of days</th>
            <th>From date</th>
            <th>To Date</th>
            <th>Leave Type</th>
            <th>Status</th>
            <th>Reason</th>
            <th>Applied on</th>
            <th>Manager comments</th>
            <th>Visit</th>
          </tr>
        </thead>
        <tbody>
        {
        LeaveArr.map(a=>
          <tr>
            <td>{a.leave_ID}</td>
            <td>{a.employee_Id}</td>
            <td>{a.number_of_Days}</td>
            <td>{a.start_Date}</td>
            <td>{a.end_Date}</td>
            <td>{a.leave_Type}</td>
            <td>{a.status}</td>
            <td>{a.reason}</td>
            <td>{a.applied_ON}</td>
            <td>{a.manager_comments}</td>
            <td>
              <p> <Link to={"/ApproveDenyMgr/"+a.leave_ID}>
              <button className="btn btn-outline-info mx-2">Click here</button>
              </Link></p>
            </td>
          </tr>
        )}   
        
      
          
        </tbody>
     
      </Table>
      <p> <Link as={Link} to="/EmployeeDashboard2">
        <button type="button" class="btn btn-sm btn-outline-secondary">Back</button>
        </Link></p>
      </>

    )
  }
}
