import React, { Component } from 'react'
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import axios from 'axios';
import CurrDate from './CurrDate';
import { Link } from 'react-router-dom';

export default class LeaveDetails extends Component {

  constructor() {
    super();
    this.state = {

      "employee_Id": '',
      "manager_Id": '',
      "number_of_Days": '',
      "start_Date": '',
      "end_Date": "",
      "leave_Type": "",
      "status": "",
      "reason": "",
      "applied_ON": "",
      "manager_comments": ""

    }
    this.create = this.create.bind(this);
    this.handleChange = this.handleChange.bind(this);
  }
  create() {
  
    const UserID = localStorage.getItem("employee_Id");
    const ManagerID = localStorage.getItem("manager_Id");

    axios.post("http://localhost:59992/api/LeaveInfo/NewLeave", {
      employee_Id: UserID,
      manager_Id: ManagerID,
      number_of_Days: this.state.number_of_Days,
      start_Date: this.state.start_Date,
      end_Date: this.state.end_Date,
      leave_Type: this.state.leave_Type,
      status: "Pending",
      reason: this.state.reason,
      applied_ON: CurrDate("-"),
      manager_comments: "NA"
    }
    ).then(response => {
      console.log(response);
      alert("Leave applied successfully");

    })
      .catch(err => {
        console.warn(err);
      })
  }

  handleChange(e) {
    this.setState(e);
  }


  render() {
    return (
      <>
      <div class="row justify-content-center row row-cols-1 row-cols-sm-1 row-cols-md-2 g-4"row justify-content-center>
      <Form>

        <label><h1 >Apply Leave</h1></label>
        <Form.Group className="mb-3" controlId="formBasicStartDate">
          <Form.Label>From date</Form.Label>
          <Form.Control type="date" onChange={(e) => this.handleChange({ start_Date: e.target.value })} placeholder="From date" />
          <Form.Text className="text-muted">
            Enter the start date.
        </Form.Text>
        </Form.Group>
        <Form.Group className="mb-3" controlId="formBasicEndDate">
          <Form.Label>To date</Form.Label>
          <Form.Control type="date" onChange={(e) => this.handleChange({ end_Date: e.target.value })} placeholder="To date" />
          <Form.Text className="text-muted">
            Enter the End date.
        </Form.Text>
        </Form.Group>



        <Form.Group className="mb-3" controlId="formBasicnumber_of_Days">
          <Form.Label>number of Days</Form.Label>
          <Form.Control type="text" onChange={(e) => this.handleChange({ number_of_Days: e.target.value })} placeholder="number of Days" />

        </Form.Group>

        <Form.Group className="mb-3" controlId="formBasicReason">
          <Form.Label>Reason for leave</Form.Label>
          <Form.Control type="text" onChange={(e) => this.handleChange({ reason: e.target.value })} placeholder="Reason" />

        </Form.Group>

        <Form.Group className="mb-3" controlId="formBasicDropDown">
          <Form.Label>Select the type of leave </Form.Label>

          <select id="Leave" name="Leave" onChange={(e) => this.handleChange({ leave_Type: e.target.value })}>
          <option value="Earned Leave">Choose</option>
            <option value="Earned Leave">Earned Leave</option>
            <option value="Maternity Leave">Maternity Leave</option>
            <option value="Sick Leave">Sick Leave</option>

          </select>
        </Form.Group>

        <Button variant="primary" type="Submit" onClick={this.create}>
          Apply Leave
      </Button>
      <br/><br/>
      <p> <Link as={Link} to="/EmployeeDashboard2">
      <Button variant="primary" type="Submit" >
          Back
      </Button>
      </Link></p>
      
      

      </Form >
      

      </div>
      
      </>
    )
  }
}
