import {React,useState,useEffect} from 'react'
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import InputGroup from 'react-bootstrap/InputGroup';
import Table from 'react-bootstrap/Table';
import { Link, useParams } from 'react-router-dom';
import axios from 'axios'

export default function ApproveDenyMgr(props) {
  const params= useParams();
  const{id} = params;


  const [pendingLeave, setpendingLeave] = useState({
    leave_ID:"",
    employee_Id:"",
    number_of_Days:"",
    start_Date:"",
    end_Date:"",
    leave_Type:"",
    status:"",
    reason:"",
    manager_comments:""
  });

  const {leave_ID,employee_Id,number_of_Days,start_Date,end_Date,leave_Type,status,reason,manager_comments}=pendingLeave;


  useEffect(()=>{
    axios.get("http://localhost:59992/api/LeaveInfo/LeaveById?id="+id).
    then(result=>setpendingLeave(result.data))
  
      
  },[])


  function getData(val)
{
  setpendingLeave({...pendingLeave, manager_comments:val.target.value})
 
}
const Approve = async e => {
  

  e.preventDefault();
 
  
   await axios.patch("http://localhost:59992/api/LeaveInfo/changestatus/"+id,{...pendingLeave, status:"Approved"}).
   then(result=>{
     window.location="/ApproveDeny";
   });
  
 };


 const Deny = async e => {
  

  e.preventDefault();
 
  
   await axios.patch("http://localhost:59992/api/LeaveInfo/changestatus/"+id,{...pendingLeave, status:"Denied"}).
   then(result=>{
     window.location="/ApproveDeny";
   });
  
 };


  return (
    <div>
        <>
<label><h1>Pending Applications</h1></label>
<Table striped bordered hover variant="dark">
<thead>
  <tr>
    <th>Leave ID</th>
    <th>Employee ID</th>
    <th>Number of days</th>
    <th>From date</th>
    <th>To Date</th>
    <th>Leave Type</th>
    <th>Status</th>
    <th>Reason</th>
    
    
    
  </tr>
</thead>
<tbody>

  <tr>
    <td>{leave_ID}</td>
    <td>{employee_Id}</td>
    <td>{number_of_Days}</td>
    <td>{start_Date}</td>
    <td>{end_Date}</td>
    <td>{leave_Type}</td>
    <td>{status}</td>
    <td>{reason}</td>
    
    
   
  </tr>



  
</tbody>

</Table>
<br/>
<br/>

<InputGroup>
<InputGroup.Text>Manager comments</InputGroup.Text>
<Form.Control as="textarea" onChange={getData} aria-label="With textarea" />
</InputGroup>

{/* <textarea className="form-control" onChange={getData} name="comment"aria-label="With textarea" placeholder="Enter Comment" required></textarea> */}

<br/>
<br/>

<Button variant="outline-dark" onClick={Approve} >Approve</Button> <Button variant="outline-dark" onClick={Deny}>Deny</Button>



<br/>
<br/>


<p> <Link as={Link} to="/EmployeeDashboard2">
<button type="button" class="btn btn-sm btn-outline-secondary">Back</button>
</Link></p>

</>
        
    </div>
)
}
