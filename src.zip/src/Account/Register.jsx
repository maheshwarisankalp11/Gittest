import React, { Component } from 'react'
import Card from 'react-bootstrap/Card';
import { Link } from 'react-router-dom';
export default class Register extends Component {

    constructor() {
        super();
        this.state = {
            Employee: [],
            full_Name: '',
            password: '',
            email_Address: '',
            mobile_Number: '',
            date_Joined: '',
            department: '',
            manager_Id: ''

        }
        this.create = this.create.bind(this);
        this.handleChange = this.handleChange.bind(this);
    }
    create() {
        fetch("http://localhost:59992/api/EmployeeInfo/AddEmployee",
            {
                "method": "POST",
                "headers": {
                    "content-type": "application/json",
                    "accept": "application/json"
                },
                body: JSON.stringify({
                    full_Name: this.state.full_Name,
                    email_Address: this.state.email_Address,
                    mobile_Number: this.state.mobile_Number,
                    password: this.state.password,
                    department: this.state.department,
                    date_Joined: this.state.date_Joined,
                    manager_Id: '1'

                })

            }).then(response => response.json()).then(response => {

                alert("Registration Successful");
            })
            .catch(err => {
                console.warn(err);
            })
    }
    handleChange(e) {
        this.setState(e);
    }





    render() {
        return (
            <>
                <br />
                <br />
                <br />
                <br />
                <br />
                <div class="row row-cols-1 row-cols-sm-1 row-cols-md-2 g-4">
                    <Card>
                        <Card.Body>
                            <form>
                                <h3>Register</h3>

                                <div className="form-group">
                                    <label>First name</label>
                                    <input type="text" name="full_Name" onChange={(e) => this.handleChange({ full_Name: e.target.value })} className="form-control" placeholder="full_Name" />
                                </div>

                                <div className="form-group">
                                    <label>Email</label>
                                    <input type="email" name="Email" onChange={(e) => this.handleChange({ email_Address: e.target.value })} className="form-control" placeholder="Enter Email" />
                                </div>

                                <div className="form-group">
                                    <label>Phone Number</label>
                                    <input type="text" name="Number" onChange={(e) => this.handleChange({ mobile_Number: e.target.value })} className="form-control" placeholder="Enter Number" />
                                </div>

                                <div className="form-group">
                                    <label>Date Of Join</label>
                                    <input type="date" name="DOJ" onChange={(e) => this.handleChange({ date_Joined: e.target.value })} className="form-control" placeholder="Date of Join" />
                                </div>

                                <div className="form-group">
                                    <label>Department</label>
                                    <input type="text" name="Department" onChange={(e) => this.handleChange({ department: e.target.value })} className="form-control" placeholder="Enter Department" />
                                </div>

                                <div className="form-group">
                                    <label>Password</label>
                                    <input type="password" className="form-control" onChange={(e) => this.handleChange({ password: e.target.value })} placeholder="Enter password" />
                                </div>
                                <br/>
                                <button type="submit" onClick={this.create} className="btn btn-outline-info">Register</button>
                                <br/><br/>
                                <p> <Link as={Link} to="/Login">
                                        <button type="button" class="btn btn-outline-info">Back</button>
                                 </Link></p>

                            </form>
                        </Card.Body>
                    </Card>
                </div>
            </>

        )
    }
}
