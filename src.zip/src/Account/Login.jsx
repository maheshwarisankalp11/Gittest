import React, { Component } from 'react'
import Card from 'react-bootstrap/Card';
import Alert from 'react-bootstrap/Alert';
import EmpDash from '../Employee/EmployeeDashboard'
import axios from 'axios'
import { Link } from 'react-router-dom';
import './Login.css';
export default class Login extends Component {

  constructor() {
    super();
    this.state = {
      Employee: [],
      email_Address: '',
      password: ''
    }
    this.Login = this.Login.bind(this);
    this.handleChange = this.handleChange.bind(this);
  }

  Login(e) {
    e.preventDefault();
    let email_Address = this.state.email_Address;
    let password = this.state.password;
    axios.get('http://localhost:59992/api/EmployeeInfo/Login/' + email_Address + '/' + password)
      .then(res => res
      )
      .then(result => {
        console.log(result);
        localStorage.setItem("employee_Id", result.data.employee_Id);
        localStorage.setItem("manager_Id", result.data.manager_Id);
        //alert(result);
        if (result != null) {
          //alert("Valid");

          window.location = "/EmployeeDashboard2";
          localStorage.setItem("UserName", email_Address)

        }
        else {
          alert("InValid");


        }
      })
      .catch(err => {
        console.log(err);
        alert("Enter valid credentials");



      });
  }
  handleChange(e) {
    this.setState(e);
  }






  render() {
    return (
      <>
        <br />
        <br />
        <br />
        <br />
        <br />
        
        <div class="row row-cols-1 row-cols-sm-1 row-cols-md-2 g-4">
        

          <Card >

            <Card.Body>

              <form>

                <h2>LOGIN</h2>

                <div className="form-group">
                  <label>Email</label>
                  <input type="email" name='email' onChange={(e) => this.handleChange({ email_Address: e.target.value })} className="form-control" placeholder="Enter email" />
                  <label className="text-muted">
                    We'll never share your email and password with anyone else.
        </label>
                </div>

                <div className="form-group">
                  <label>Password</label>
                  <input type="password" name='password' onChange={(e) => this.handleChange({ password: e.target.value })} className="form-control" placeholder="Enter password" />
                  {/* <label className="text-muted">
                    Your password must be 8-20 characters long, contain letters and numbers,
                    and must not contain spaces, special characters, or emoji.
        </label> */}
                </div>

                {/* <div className="form-group">
                  <div className="custom-control custom-checkbox">
                    <input type="checkbox" className="custom-control-input" id="customCheck1" />
                    <label className="custom-control-label" htmlFor="customCheck1">Remember me</label>
                  </div>
                </div> */}
                <br/>

                <button type="submit" onClick={this.Login} className="btn btn-outline-info">Login</button>
                {/* <p className="forgot-password text-right">
              Forgot <a href="#">password?</a>
            </p> */}

                <p className="Sign_Up text-right">
                  Don't have an account yet? <Link to='/Register'>Register</Link>
                </p>


              </form>
            </Card.Body>
          </Card>
        </div>

      </>

    )
  }
}
