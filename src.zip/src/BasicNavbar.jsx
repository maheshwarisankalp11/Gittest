import React from 'react';
import ManagerDetails from './Manager/ManagerDetails';
import ManagerLogin from './Manager/ManagerLogin';
import LeaveDetails from './LeaveSection/LeaveDetails';
import EmpDetails from './Employee/SearchEmpById';
import ApproveDeny from './LeaveSection/ApproveDeny';
import EmployeeDashboard2 from './Employee/EmployeeDashboard2';
import ApplicationSts from './LeaveSection/ApplicationSts';
import ApproveDenyMgr from './LeaveSection/ApproveDenyMgr';

import Nav from 'react-bootstrap/Nav';
import { BrowserRouter, Routes, Route, Link } from "react-router-dom";

import Navbar from 'react-bootstrap/Navbar';


import EmployeeDashboard from './Employee/EmployeeDashboard';

import Login from './Account/Login'
import Register from './Account/Register';
// import App2 from './App2';

export default function BasicNanbar() {
  return (

    <div className='container-fluid nav_bg'>
      {/* <div className='row'> */}
        <div className=''>
          <BrowserRouter>
            {/* <div >

              <Navbar bg="light" variant="light" expand="lg">
                <Navbar.Brand as={Link} to="/Login"><h1>Leave Management System</h1> </Navbar.Brand>
                <Navbar.Toggle aria-controls="navbarScroll" />
                <Navbar.Collapse id="navbarScroll">
                  <Nav

                    className="ms-auto my-2 my-lg-0"
                    style={{ maxHeight: '100px' }}
                    navbarScroll
                  >




                  </Nav>

                </Navbar.Collapse>
              </Navbar>
            </div> */}
            {/* <div> */}
              <Routes>
                <Route path='/' element={<Login></Login>}></Route>
                
                <Route path='/Login' element={<Login></Login>}></Route>
                <Route path='/ManagerDetails' element={<ManagerDetails />}></Route>
                <Route path='/ManagerLogin' element={<ManagerLogin />}></Route>
                <Route path='/LeaveDetails' element={<LeaveDetails />}></Route>
                <Route path='/EmpDetails' element={<EmpDetails />}></Route>
                <Route path='/Register' element={<Register />}></Route>
                <Route path='/ApproveDeny' element={<ApproveDeny />}></Route>
                <Route path='/ApproveDenyMgr/:id' element={<ApproveDenyMgr />}></Route>
                <Route path='/EmployeeDashboard' element={<EmployeeDashboard></EmployeeDashboard>}></Route>
                <Route path='/EmployeeDashboard2' element={<EmployeeDashboard2></EmployeeDashboard2>}></Route>
                <Route path='/ApplicationSts' element={<ApplicationSts></ApplicationSts>}></Route>


              </Routes>
            
          </BrowserRouter>
        </div>
      
     </div>


  )
}
